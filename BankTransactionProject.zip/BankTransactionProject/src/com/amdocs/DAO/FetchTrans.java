package com.amdocs.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchTrans 
{
	
	// SQL queries
		private static final String SELECT_ALL_TRANSACTIONS = "SELECT * FROM transactions";
		
	
	// Retrieve transactions and process each one
		public static void processTransactions() throws SQLException 
		{
			// Establish a database connection
			Connection con = JDBCConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SELECT_ALL_TRANSACTIONS);

			// Process each transaction
			while (rs.next()) 
			{
				processSingleTransaction(con, rs);
			}

		}

		// Process a single transaction
		private static void processSingleTransaction(Connection con, ResultSet rs) throws SQLException 
		{
			// Extract transaction details from the result set
			int transID = rs.getInt(1);
			int acctNo = rs.getInt(2);
			double oldBal = rs.getDouble(3);
			String transType = rs.getString(4);
			double transAmt = rs.getDouble(5);

			// Calculate new balance and determine transaction validity
			double newBal = calculateNewBalance(oldBal, transType, transAmt);

			String validity = "";

			if (newBal < 0) 
			{
				validity = "Invalid";
			} 
			else 
			{
				validity = "Valid";
			}

			// Update transaction details in the database
			UpdateTrans.updateTransaction(con, newBal, validity, transID);

			// Determine the target table based on transaction validity and insert the transaction
			String tableName = "";

			if (validity.equals("Valid")) 
			{
				tableName = "ValidTrans";
			} 
			else 
			{
				tableName = "InValidTrans";
			}

			InsertTrans.insertIntoTransactionTable(con, tableName, transID, transType, transAmt, validity);

		}
		
		// Calculate new balance based on transaction type
		private static double calculateNewBalance(double oldBal, String transType, double transAmt) 
		{
			
			// Determine the new balance based on the transaction type
			if (transType.equals("W")) 
			{
				return oldBal - transAmt;	
			} 
			else 
			{
				return oldBal + transAmt;
			}

		}


	

}
