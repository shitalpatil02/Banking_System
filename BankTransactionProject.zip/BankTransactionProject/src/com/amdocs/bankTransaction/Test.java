package com.amdocs.bankTransaction;

import com.amdocs.DAO.JDBCConnection;
import com.amdocs.DAO.AllTransactions;
import com.amdocs.DAO.FetchTrans;

public class Test {

	
	public static void main(String[] args) 
	{

		try {
			// Process transactions and print success message
			FetchTrans.processTransactions();
			System.out.println("Success");
			
			System.out.println();
			
			AllTransactions.displayAllRecords();
			
			// Close the database connection
			JDBCConnection.closeConnection();
		} 
		catch (Exception e) 
		{
			// Print the stack trace in case of an exception
			e.printStackTrace();
		} 

	}
}

